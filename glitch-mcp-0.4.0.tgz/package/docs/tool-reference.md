# Tool Reference

All tools are exposed by the public MCP adapter and fulfilled by the hosted Glitch MCP facade.

## Common Rules

- `title_id` is optional only when `GLITCH_TITLE_ID` is set or `glitch_select_title` has been called in the current stdio session.
- All paid and permission checks happen server-side.
- Mutating tools return sanitized errors when subscription, scope, billing, approval, or account connection checks fail.
- `glitch_approve_action` and `glitch_execute_action` require `confirm=true`.
- Hosting creation, deployment, publishing, and rollback require `confirm=true`.

## Tools

### glitch_auth_status

Checks current auth, title access, and entitlement state.

Input:

```json
{
  "title_id": "title_123"
}
```

### glitch_list_titles

Lists titles visible to the current user token or title MCP token.

Input:

```json
{
  "include_archived": false
}
```

### glitch_select_title

Verifies title access and stores the selected title for the current local stdio process.

Input:

```json
{
  "title_id": "title_123"
}
```

### glitch_get_title_context

Fetches safe title context for planning and analysis.

Input:

```json
{
  "title_id": "title_123"
}
```

### AI game-development prompts and design tools

These public tools do not require `title_id`. They expose the same stable prompt
ids and wording as the Glitch AI Game Development Prompts website. The bundled
prompt catalog is public editorial guidance and is separate from private Glitch
Agent planner prompts.

#### glitch_list_game_development_prompts

Searches prompt metadata. `category` may be `all`, `foundation`, `visuals`,
`media`, `feedback`, or `launch`.

```json
{
  "category": "foundation",
  "search": "automation"
}
```

Each result includes a stable `id`, an MCP `resource_uri`, and a Glitch web URL.

#### glitch_get_game_development_prompt

Returns the complete Markdown for one prompt. Every bundled prompt ends with the
required game-documentation section.

```json
{
  "prompt_id": "remote-game-automation"
}
```

#### glitch_list_game_genres

Fetches the live, alphabetized Glitch genre taxonomy from `GET /util/genres`.
Games may select one to eight exact genre names for blueprint generation.

```json
{}
```

#### glitch_generate_game_design_blueprint

Generates a game descriptor, core fantasy, core verbs, design pillars,
mechanics, moment-to-moment core loop, session loop, core playtest question,
scope rules, and a `documentationInstruction`. The OpenAI-backed request may
take about a minute; the MCP emits progress/log notifications and allows at
least two minutes for the hosted response. If the hosted route is unavailable,
the tool returns the same deterministic documentation-ready fallback used by
the public website instead of failing the workflow.

```json
{
  "game_name": "Signal Garden",
  "genres": ["Cozy", "Puzzle"],
  "play_mode": "cooperative",
  "session_length": "15–30 minute",
  "player_fantasy": "two signal gardeners reconnecting isolated communities",
  "setting": "floating islands where radio signals grow as plants",
  "primary_goal": "restore the shared broadcast before the seasonal storm",
  "main_pressure": "signals decay while each island asks for different help",
  "signature_twist": "tuning one signal changes every nearby plant",
  "progression": "unlock new instruments and signal seeds",
  "preferred_activities": "listen, tune, plant, connect"
}
```

Do not submit a duplicate generation call while the first request is still
running. When repository access is available, save or update the generated
blueprint at the path specified by `documentationInstruction`.

### glitch_get_billing_status

Fetches subscription, trial, credits, plan, and entitlement status.

Input:

```json
{
  "title_id": "title_123"
}
```

### Game website hosting

`glitch_get_hosting` returns the hosting account, pooled bandwidth usage,
sites, releases, domains, databases, and current plan catalog.

`glitch_get_hosting_analytics` returns website Hosting and Glitch Store channels
separately, plus a combined title view. Optional dates use `YYYY-MM-DD`.

`glitch_create_hosting_site` creates a static or server/SSR site with a free
`game.business.glitch.fun` address.

`glitch_update_hosting_site` changes the name, mode, player region, or ordinary
runtime configuration. MCP rejects secret-shaped keys and values; use managed
Glitch bindings for credentials.

`glitch_list_hosting_releases` lists immutable releases and their processing
state. Use a ready release id with `glitch_promote_hosting_release` to publish or
roll back.

`glitch_deploy_hosting_build` deploys an existing compatible Glitch game build
to Hosting. Call `glitch_list_deployments` first and reuse a compatible
processing or ready build. The tool resumes by build id and waits for a
processing build to become ready. Never call `glitch_update_deployment_status`
with `ready` while a build is processing; Glitch returns HTTP 400. When
the title has one site it selects it automatically. When no site exists, pass
`site_name` and `site_slug`; Node builds default to server mode and other builds
default to static mode. The tool waits for both build and hosting release
processing and publishes unless `publish=false`.

Persist the build id returned by `glitch_deploy_game_build`. If the client or
agent restarts, list deployments and resume that same id instead of uploading
the unchanged ZIP again. Upload another build only when no compatible build
exists or after a failed build has been corrected.

For a Node build, the finished ZIP must contain `package.json`, the executable
production entry, and a production `Dockerfile` in the same build context.
Place `Dockerfile` at the ZIP root by default, bind the app to `0.0.0.0`, and
align application `PORT`, Dockerfile `EXPOSE`, and `custom_variables.target_port`
on one explicit port. The standard contract is `HOST=0.0.0.0`, `PORT=3000`,
`EXPOSE 3000`, and `target_port=3000`.

`entry_point` is required and must be proven from the finished artifact. The
tool rejects `package.json` as an entry. Use `index.html` only when that exact
file is the real browser bootstrap, or use the executable server module that
binds `PORT`. A ready result is not live; activation still requires successful
HTTPS/routing and final public-site verification. If promotion returns an
incident reference, retry the same release instead of creating a duplicate.

Developers do not need to provide a custom smoke-test suite. Glitch runs the
mandatory acceptance checks appropriate to the deployment type, and build
variables cannot disable them. While a build is processing, clients should show
`processing_stage`. A failed build should surface its build id, `error_code`,
`failure_stage`, `retryable`, `error_message`, and `remediation`; a poll timeout
means resume the same build id, not create or activate another build.

For a browser surface embedded in the Glitch Store, use the canonical Aegis
bridge URL `https://api.glitch.fun/js/aegis-bridge.js`. Glitch automatically
injects it only into the exact static HTML/HTM entry and discovered standard
Pixel Streaming `player.html`/`player.htm` pages. Normal Node/SSR entries,
streamed-native/noVNC frontends, generic container images, non-HTML static
entries, and custom Pixel Streaming frontends must add the script once to their
real browser layout. Hosting-only pages do not need the Store parent bridge
unless that same surface is also embedded in the Store. Verify the final served
page loads the canonical URL once; do not copy it locally or put secrets in
`window.AEGIS_CONFIG`.

```json
{
  "title_id": "title_123",
  "game_build_id": "build_123",
  "site_name": "Neon Drift",
  "site_slug": "neon-drift",
  "version": "1.4.0",
  "entry_point": "dist/index.html",
  "publish": true,
  "confirm": true
}
```

Use `glitch_deploy_game_build` only when no compatible existing build is ready and
the artifact exists only as a local ZIP. Use
`glitch_promote_hosting_release` with a previous release id to roll back. Hosting
and Store distribution remain separate.

#### Multi-service and persistent online games

- `glitch_list_hosting_services` returns the current public, private, singleton, replicated, worker, and scheduled topology without secrets.
- `glitch_estimate_hosting_services` is read-only. It accepts `single_server`, `stateful_game_server`, `web_and_api`, `authoritative_world`, or `large_realtime_world`, plus per-service overrides and ready container build ids.
- `glitch_apply_hosting_services` queues an immutable service-stack release. It requires `confirm=true`, the reviewed `expected_monthly_floor_cents`, and `DEPLOY HOSTING STACK AT ESTIMATED FLOOR <cents> CENTS PER MONTH PLUS USAGE`.

Use `stateful_game_server` for an authoritative MMO shape with separate
readiness/liveness checks and persistent media/spool mounts. Use
`large_realtime_world` for replicated web and WebSocket routes, a private world
simulation, and workers. Multi-service shapes require the AI to send
the inspected `services` manifest with the image's real `command`/`arguments`;
the preset by itself is an estimate, not permission to guess entrypoints.

One ready container image may be reused with different commands. `public_paths`
routes prefixes such as `/sync/` or `/api/assets` to the correct public service;
`/` belongs only to the primary service. Authoritative world processes must be
singleton. Dependencies receive `GLITCH_SERVICE_<SLUG>_URL`. `volumes` creates
durable file mounts with `name`, absolute `mount_path`, `size_gb`, and optional
`ReadOnly`/`ReadWrite` access. Managed database bindings are injected before
health checks. Tests and migrations may run as one-time jobs before the release
becomes ready. Secret values never pass through MCP; create the required secret
names in the signed-in Hosting page.

Service pricing is independent of game count. The Hosting plan covers website
bandwidth/release storage; service stacks add metered vCPU time, allocated
memory time, requests, scale-out, scheduled-job runtime, and persistent file
capacity. Database and Redis add-ons are separate monthly items.

#### Domains

- `glitch_connect_hosting_domain` connects a domain already owned by the developer and returns public DNS instructions.
- `glitch_verify_hosting_domain` rechecks public DNS and activates the domain.
- `glitch_check_hosting_domain` returns Glitch-supported availability, live annual price, and current agreement keys without buying anything.
- `glitch_purchase_hosting_domain` requires `accepted_legal_terms=true`, every current agreement key, registrant contact details, `confirm=true`, the exact annual price, and `PURCHASE DOMAIN <hostname> AT <cents> CENTS PER YEAR`.

The purchase tool returns secure checkout. Domain registration does not begin
until `glitch_confirm_hosting_checkout` verifies paid checkout with the payment
provider. If the live price changes before checkout is created, Glitch returns a
conflict and requires a fresh confirmation.

#### Managed database add-ons

The MCP supports only Glitch-managed choices: PostgreSQL, MySQL, SQL, NoSQL,
and Redis. Marketplace database products are
not accepted.

- `glitch_list_hosting_databases` and `glitch_get_hosting_database` return safe status, endpoint, port, storage, and binding metadata.
- `glitch_create_hosting_database` creates paid Checkout for a self-service database size.
- `glitch_update_hosting_database` changes size or safeguards; a size change requires `accept_proration=true`.
- `glitch_retry_hosting_database` retries failed provisioning or returns a new Checkout for an unpaid database.
- `glitch_delete_hosting_database` requires `confirm=true` and the exact database name.

Creation confirmation format:

```text
CREATE DATABASE <NAME> ON <PLAN> AT <CENTS> CENTS PER MONTH
```

Update and retry confirmation formats are returned by the server when the
current database name, plan, or price must be reviewed. Database credentials,
secret references, and full connection strings are never returned by MCP. A
signed-in business billing administrator can use **View credentials** on the
game's Hosting page after typing the exact database name. That reveal is
rate-limited, non-cacheable, audit-logged, and automatically hidden by the UI;
do not ask the developer to paste it into an MCP or AI conversation.

#### Hosting plan billing

`glitch_change_hosting_plan` manages the bandwidth-based Hosting subscription,
separate from Store distribution. It requires:

```text
CHANGE HOSTING PLAN TO <PLAN> AT <CENTS> CENTS PER MONTH
```

Changing an active paid plan requires `accept_proration=true`. Direct accounts
return secure checkout. Microsoft Marketplace accounts return a pending
Marketplace operation and remain on the customer's Microsoft invoice. AWS
Marketplace accounts return the AWS subscription-management URL; the customer
finishes the paid plan change there and Glitch applies it after the signed AWS
license entitlement event arrives. AWS Marketplace does not expose the Free
Hosting plan.
`glitch_confirm_hosting_checkout` is used only when Glitch returned a direct
Checkout session id; payment credentials never pass through MCP.

The Hosting dashboard returns `account.billing_provider`. Use
`monthly_price_cents` for `direct` accounts and
`marketplace_monthly_price_cents` for `microsoft_marketplace` accounts when
preparing exact confirmation phrases. Use
`aws_marketplace_monthly_price_cents` for `aws_marketplace` accounts. Both
Marketplace channels include the 20% adjustment and ending-in-9 rounding.

#### AI deployment guide

`glitch_generate_hosting_ai_instructions` creates a complete, copy-and-paste
deployment runbook for a chosen framework, domain, and database add-ons. It
covers NPX, installed and project-local CLI, CI, TypeScript SDK, MCP, all CLI
options, response/status contracts, retries, rollback, verification, managed
bindings, multi-service presets, singleton handoff, jobs, migrations, and
approval boundaries without passwords or private infrastructure.

### glitch_get_analytics_capabilities

Returns the authoritative title-scoped analytics contract: all families,
canonical report keys, accepted/default filters, source dashboard routes,
required context, and query limits. Call it when the exact report key or filter
shape is not already known.

Input:

```json
{
  "title_id": "title_123"
}
```

### glitch_get_analytics_report

Runs one canonical dashboard report without starting or billing an Agent run.

Input:

```json
{
  "title_id": "title_123",
  "report_key": "retention.d7",
  "filters": {
    "start_date": "2026-07-01",
    "end_date": "2026-08-01",
    "platform": ["steam", "pc"]
  },
  "fail_fast": false
}
```

### Analytics family tools

- `glitch_get_session_reports`
- `glitch_get_web_reports`
- `glitch_get_storefront_reports`
- `glitch_get_wishlist_reports`
- `glitch_get_earnings_reports`
- `glitch_get_attribution_reports`
- `glitch_get_cross_device_reports`

Each family tool accepts the same bundle shape:

```json
{
  "title_id": "title_123",
  "report_keys": ["retention.d7", "behavioral_funnels.report"],
  "filters": {
    "start_date": "2026-07-01",
    "end_date": "2026-08-01",
    "per_page": 50
  },
  "report_filters": {
    "behavioral_funnels.report": {
      "funnel_id": "auto-observed-journey"
    }
  },
  "fail_fast": false
}
```

Analytics rules:

- All operations are read-only and require the existing `reports:read` title
  MCP ability.
- Raw identity-level fields are recursively redacted unless the credential also
  has `reports:identity`. Capabilities expose whether identity detail is included
  and mark reports that can contain identity-level rows.
- The hosted backend reuses the same controllers and calculations as the
  Glitch dashboard instead of maintaining a second analytics implementation.
- A request may include at most 25 reports, a date range may cover at most 365
  days, and page/row limits are capped at 100.
- Common `filters` apply only where a report advertises that filter. The result
  records ignored filters so a client can identify mismatches. Applied filters
  contain only values actually forwarded to the canonical controller; identity
  filter values are shown as `[redacted]` without `reports:identity`.
- `report_filters` overrides common filters for one report.
- Bundles return partial results by default. Every report includes `ok`,
  `status`, `empty`, applied `filters`, ignored filters, source information,
  `data`, and a sanitized `error` when unavailable.
- Optional-context reports can be unavailable without making the whole bundle
  fail. Do not interpret unavailable or empty reports as numeric zero.
- Attribution ad reports that advertise `scheduler_id` require it explicitly;
  they are not part of the default attribution bundle.
- The default attribution and cross-device bundles reproduce the corresponding
  Glitch report pages, including their supporting session, earnings, retention,
  landing-page, attribution-summary, environment, geography, fraud, install-
  journey, and campaign-performance sections.

### glitch_get_social_capabilities

Returns the authoritative title-scoped social contract. The result includes platform publishing, comment, reply, messaging, engagement, history, and metrics capabilities; safe connected-scheduler summaries; and every supported operation with its category, required ability, confirmation requirement, destructive flag, and required arguments.

Input:

```json
{
  "title_id": "title_123"
}
```

Call this before `glitch_social_operation` instead of guessing operation names or platform support.

### glitch_social_operation

Executes one deterministic operation from `glitch_get_social_capabilities`.

Input:

```json
{
  "title_id": "title_123",
  "operation": "posts.reschedule",
  "arguments": {
    "post_id": "post_123",
    "scheduled_at": "2026-08-03T15:00:00Z"
  },
  "confirm": true
}
```

Rules:

- Read operations run without confirmation.
- Mutations, publishing, engagement, messaging, syncing, account disconnects, and destructive operations require `confirm=true`.
- The title MCP token must have the operation's advertised granular ability.
- Resource identifiers are checked against the selected title before existing Glitch social controllers or facades run.
- OAuth tokens, refresh tokens, passwords, API keys, authorization headers, and credential-shaped fields are rejected as input and recursively removed from output.
- OAuth account connection remains a browser consent flow. Use the returned dashboard links to connect or reauthenticate accounts.
- Results use `{ "operation": "...", "result": ... }`; asynchronous platform jobs retain their existing Glitch job/status fields.

### glitch_start_agent_run

Starts a Glitch Agent run.

Input:

```json
{
  "title_id": "title_123",
  "agent_id": "agent_123",
  "prompt": "Review our Steam page and create launch recommendations.",
  "run_type": "manual",
  "trigger_source": "mcp",
  "live_mode": false,
  "background": true,
  "wait_for_completion": false,
  "timeout_ms": 120000,
  "poll_interval_ms": 2000,
  "attachment_ids": [],
  "tool_command": {},
  "session_context": {}
}
```

Notes:

- `agent_id` may be omitted when the hosted service can choose the title's default MCP agent.
- `background=true` is recommended.
- If `wait_for_completion=true`, the adapter polls until completed, failed, blocked, canceled, needs guidance, needs approval, or timeout.

### glitch_get_agent_run

Fetches a durable agent run.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123"
}
```

### glitch_wait_for_agent_run

Waits for a run to settle. When `stream` is true (default) and the client accepts notifications, live events are streamed as MCP progress + log notifications (via the backend SSE endpoint), with automatic fallback to polling.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123",
  "timeout_ms": 180000,
  "poll_interval_ms": 2000,
  "stream": true
}
```

### glitch_list_run_events

Lists user-visible events.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123",
  "after_id": "event_123",
  "limit": 100
}
```

### glitch_get_final_report

Fetches final or partial report.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123"
}
```

### glitch_list_artifacts

Lists run artifacts.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123"
}
```

### glitch_list_pending_actions

Lists agent actions.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123",
  "status": "pending",
  "limit": 50
}
```

Allowed statuses:

```text
pending
proposed
needs_guidance
needs_approval
approved
executed
rejected
failed
canceled
all
```

### glitch_approve_action

Approves an action. Does not guarantee live execution.

Input:

```json
{
  "title_id": "title_123",
  "action_id": "action_123",
  "confirm": true,
  "note": "Approved from MCP after review."
}
```

### glitch_reject_action

Rejects an action.

Input:

```json
{
  "title_id": "title_123",
  "action_id": "action_123",
  "reason": "Too aggressive for current positioning."
}
```

### glitch_execute_action

Requests execution for an approved action.

Input:

```json
{
  "title_id": "title_123",
  "action_id": "action_123",
  "confirm": true,
  "note": "Execute the approved draft."
}
```

Server-side guardrails still apply to spend, public posting, creator contact, connected accounts, and missing context.

### glitch_list_guidance

Lists guidance requests.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123",
  "status": "open",
  "limit": 50
}
```

### glitch_answer_guidance

Answers a single guidance request directly (no prompt). Use this when the model or developer already knows the answer.

Input:

```json
{
  "title_id": "title_123",
  "guidance_id": "guidance_123",
  "answer": "Use a $500 test budget.",
  "payload": {}
}
```

### glitch_resolve_guidance

Presents the agent's open stop-gate questions to the **user** as interactive multiple-choice prompts (MCP elicitation) and routes each selection back to resume the run. The agent's options become a choice list with its recommended option preselected; a free-text prompt is used when a question has no options. The user can decline, in which case the question is left open and nothing is answered.

If the client does not support elicitation, the tool returns the questions as a readable multiple-choice list and asks the model/developer to answer with `glitch_answer_guidance` — so behavior degrades gracefully.

Input:

```json
{
  "title_id": "title_123",
  "run_id": "run_123",
  "guidance_id": "guidance_123",
  "limit": 5
}
```

All fields are optional: omit `guidance_id` to resolve all open questions (up to `limit`), and omit `run_id` to cover the whole title.

### glitch_setup_social_asset_folders

Creates the local developer folders Glitch watches for social-ready game assets:

```text
captures/
screenshots/
trailers/
builds/latest/social/
marketing/
.glitch/social-assets/
```

Input:

```json
{
  "project_root": "/Users/you/game",
  "confirm": true
}
```

The tool writes `.glitch/social-assets/config.json` and an off-by-default `.glitch/social-assets/watch.json` by default. It is only available when the MCP server is running locally over stdio with local file reads enabled.

### glitch_scan_local_social_assets

Scans configured local folders for images and videos likely to work as social content. It ranks candidates by folder, recency, filename signals, size, and media kind, dedupes repeated files by SHA-256 content hash, then writes `.glitch/social-assets/candidates.json` for review.

Input:

```json
{
  "project_root": "/Users/you/game",
  "max_files": 50,
  "since_hours": 168
}
```

The result includes candidate ids, SHA-256 hashes, reasons, and suggested platforms. Scanning does not upload anything.

### glitch_start_social_asset_watch

Activates the opt-in local watcher for the current stdio MCP process. The watcher runs the same scan and hash dedupe logic on an interval, defaulting to once per day. It only updates the local manifest; it never uploads files.

Input:

```json
{
  "project_root": "/Users/you/game",
  "interval_hours": 24,
  "run_immediately": true,
  "confirm": true
}
```

The watcher remains off unless this tool is called. Restarting the MCP process requires starting the watcher again.

### glitch_stop_social_asset_watch

Disables the local social asset watcher and updates `.glitch/social-assets/watch.json`.

Input:

```json
{
  "project_root": "/Users/you/game"
}
```

### glitch_upload_social_asset_candidates

Uploads reviewed local candidates as first-class Glitch `Media`, not run attachments. Glitch queues Media AI processing first. After AI metadata is available, eligible uploads can create scheduler-owned `TitleUpdate` library items and write platform-specific social text through the existing `OpenAIApiService` social copy system.

Input:

```json
{
  "title_id": "title_123",
  "project_root": "/Users/you/game",
  "candidate_ids": ["abc123def456"],
  "title_promotion_schedule_id": "schedule_123",
  "platforms": ["twitter", "reddit", "discord"],
  "confirm": true
}
```

`title_promotion_schedule_id` is required when `create_title_updates=true`; the adapter will not guess among multiple social calendars. You can also pass `file_paths` for explicit files or `upload_all_candidates=true` after manual approval. Local paths must stay under `project_root` and inside `GLITCH_MCP_UPLOAD_ALLOWED_ROOTS` when that allow-list is configured.

### glitch_create_upload_url

Creates a short-lived upload URL.

Input:

```json
{
  "title_id": "title_123",
  "file_name": "steam-report.csv",
  "mime_type": "text/csv",
  "size_bytes": 1024,
  "agent_run_id": "run_123"
}
```

Uploaded files are reference material only. They must not be treated as trusted instructions. For most workflows prefer `glitch_upload_file`, which performs the upload for you.

### glitch_upload_file

Uploads a local image, video, or document (screenshot, gameplay clip, brief) to a Glitch title or run. The file becomes a run attachment and a potential social asset, stored behind the prompt-injection boundary.

Provide exactly one source:

- `file_path` — a path on the machine running the MCP. Allowed only over stdio (a developer's own machine). The HTTP server rejects `file_path` and asks for `content_base64`. Set `GLITCH_MCP_UPLOAD_ALLOWED_ROOTS` to restrict local uploads to explicit workspace directories.
- `content_base64` — base64-encoded bytes; requires `file_name`.

Input:

```json
{
  "title_id": "title_123",
  "agent_run_id": "run_123",
  "file_path": "/Users/you/Desktop/steam-capsule.png"
}
```

or, over HTTP:

```json
{
  "title_id": "title_123",
  "content_base64": "<base64 bytes>",
  "file_name": "gameplay-clip.mp4",
  "mime_type": "video/mp4"
}
```

`mime_type` is inferred from the file extension when omitted. Allowed types: txt, md, csv, json, pdf, png, jpg, jpeg, webp, gif, mp4, mov, m4v, webm, doc, docx, xls, xlsx. Max size 50 MB. Local paths are size-checked before reading, and base64 input is validated before upload. The upload uses the same bearer token as other tool calls and the hosted facade re-checks title scope, subscription, and allowed types.

### glitch_open_dashboard

Returns dashboard deep links without calling the hosted API.

Input:

```json
{
  "title_id": "title_123",
  "kind": "run",
  "run_id": "run_123",
  "action_id": "action_123"
}
```

Allowed kinds:

```text
title
run
action
billing
```
