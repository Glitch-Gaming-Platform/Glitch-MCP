---
description: Manage a game's Glitch Hosting website, domains, databases, and plan.
argument-hint: [title_id] [request]
---

Use Glitch MCP to manage this game's hosted website.

Optional arguments I provided: $ARGUMENTS

Start with `glitch_get_hosting`. Explain choices in plain language and keep the response short.

For deployments, first call `glitch_list_deployments` and reuse a compatible processing or ready build. Preserve and wait on a processing build id; never activate it or re-upload the unchanged artifact. Upload a local ZIP with `glitch_deploy_game_build` only when no compatible build exists. No developer-authored smoke suite is required, but Glitch's mandatory acceptance gates cannot be disabled. Surface `processing_stage` while waiting and the structured failure fields when failed. For Node builds, require a production Dockerfile in the same build context and explicitly align `HOST`, `PORT`, Dockerfile `EXPOSE`, and `target_port`. For Store-embedded pages, verify `https://api.glitch.fun/js/aegis-bridge.js`: static HTML/HTM and standard Pixel Streaming player pages are patched automatically; Node/SSR, streamed-native/noVNC, generic container, non-HTML static, and custom Pixel Streaming frontends must add it themselves. For domains, database add-ons, or plan changes, show me the exact effect and price before any confirmed call. Never set `confirm=true`, accept legal terms, accept proration, purchase anything, publish a release, or delete a database unless I explicitly approve that action.

For paid changes, use the current price and exact confirmation phrase returned or required by Glitch. Send me to secure checkout; never ask me for payment credentials.

Never place passwords, tokens, private keys, or connection strings in Hosting configuration or chat. Use the safe database binding name and `glitch_generate_hosting_ai_instructions` when code changes are needed.

Keep Hosting and Glitch Store distribution separate when reporting releases, analytics, and revenue.
